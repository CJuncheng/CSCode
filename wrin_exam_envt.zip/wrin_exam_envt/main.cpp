#include <iostream>
#include <vector>
#include <map>
#include <cctype> // tolower()
#include <utility> // pair
#include <unordered_map>
#include <map>
#include <set>
#include <fstream>
#include <sstream>
#include <memory>
#include <stdexcept>
#include <initializer_list>
#include <cstring>
using namespace std;


int main(int argc, char *argv[])
{
    int n;
    cin >> n;
    vector<int> nums(n);
    for(int i = 0; i < n; ++i) cin >> nums[i]; 
    int res = 0, max_val = nums[0];
    for(int i = 1; i < n; ++i){
        if(nums[i] < max_val) res += max_val - nums[i];
        else max_val = max(max_val, nums[i]);
    }
    cout << res << endl;
    
    return 0;
}

