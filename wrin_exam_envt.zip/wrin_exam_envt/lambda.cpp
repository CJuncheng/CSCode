#include <bits/stdc++.h>
using namespace std;
/*
int main(int argc, char* argv[]){
    //std::function<int(int, int)> sum = [&](int x, int y) -> int{
    //    return x+y;
    //};
    auto sum = [&](int x, int y) -> int{
        return x+y;
    };
    int a = sum(1, 3);
    std::cout << a << std::endl;
    return 0;
}
*/

/*
TEST (test2, function_lambda) {
    int a = 1, b = 2;
    std::function<int (const int &)> func1 = std::function<int (const int &)>([a, &b] (const int &i) {
        b = a + i;
        return a + b;
    });
 
    int c = 10;
    std::cout << func1(std::cref(c)) << std::endl;
    std::cout << a << std::endl;
    std::cout << b << std::endl;
 
    std::function<int (const int &, int &)> func2 = std::function<int (const int &, int &)>([a, &b] (const int &i, int &j) {
        int k = i + j;
        b = a + k;
        j = a + b;
        return a + b + j;
    });
 
    int d = 10, e = 20;
    std::cout << func2(d, e) << std::endl;
    std::cout << b << std::endl;
    std::cout << e << std::endl;
 
    class cls {
        int a;
        int b;
        int c;
 
    public:
        cls(int x, int y, int z):a(x), b(y), c(z){}
        ~cls(){}
 
        double CalcAverage() {
            auto calcer = std::function<double ()>([this] {
                return (a + b + c)/3.0;
            });
 
            return calcer();
        }
    };
 
    std::vector<int> v;
    std::random_device rd;
    for (auto idx: common::Range(0, 3)) {
        int i = rd() % 10;
        v.push_back(i);
        std::cout << "input " << i << std::endl;
    }
    cls cl(v[0], v[1], v[2]);
    double average = cl.CalcAverage();
    std::cout << std::fixed << std::setprecision(6) << average << std::endl;
}
*/


int main(int argc, char* argv[]){
    struct test {
        int a;
        double b;
        short c;
    };
    test A;
    cout << sizeof(A) << endl;


    return 0;
}